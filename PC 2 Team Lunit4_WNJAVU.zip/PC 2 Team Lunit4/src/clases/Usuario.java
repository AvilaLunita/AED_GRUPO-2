
package clases;

import java.util.ArrayList;
import java.util.List;


public class Usuario {
    
    private String nombre;
    private String email;
    private final List<ListaDeTareas> listasDeTareas;

    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
        this.listasDeTareas = new ArrayList<>();
    }

    
    public void agregarListaDeTareas(ListaDeTareas lista) {
        listasDeTareas.add(lista);
    }

   
    public void mostrarListasDeTareas() {
        System.out.println("Usuario: " + nombre + " - Listas de Tareas:");
        for (ListaDeTareas lista : listasDeTareas) {
            System.out.println(lista.mostrarTareas());
        }
    }

  
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
