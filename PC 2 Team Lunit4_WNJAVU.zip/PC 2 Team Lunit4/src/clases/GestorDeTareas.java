
package clases;


public class GestorDeTareas {
    
     private final ListaDeTareas listaDeTareas;

    public GestorDeTareas() {
        listaDeTareas = new ListaDeTareas();
    }

    // Método para agregar una nueva tarea
    public void agregarTarea(String nombre, int prioridad, String descripcion) {
        if (listaDeTareas.buscarTarea(nombre) == null) {
            Tarea nuevaTarea = new Tarea(nombre, prioridad, descripcion);
            listaDeTareas.agregarTarea(nuevaTarea);
            System.out.println("Tarea agregada exitosamente.");
        } else {
            System.out.println("Error: La tarea con el nombre '" + nombre + "' ya existe.");
        }
    }

    // Método para eliminar una tarea por nombre
    public boolean eliminarTarea(String nombre) {
        boolean resultado = listaDeTareas.eliminarTarea(nombre);
        if (resultado) {
            System.out.println("Tarea eliminada exitosamente.");
        } else {
            System.out.println("Error: No se encontró la tarea con el nombre '" + nombre + "'.");
        }
        return resultado;
    }

    // Método para buscar una tarea por nombre
    public Tarea buscarTarea(String nombre) {
        return listaDeTareas.buscarTarea(nombre);
    }

    // Método para mostrar todas las tareas
    public void mostrarTareas() {
        System.out.println(listaDeTareas.mostrarTareas());
    }

    // Método para ordenar las tareas por prioridad
    public void ordenarTareasPorPrioridad() {
        listaDeTareas.ordenarPorPrioridad();
        System.out.println("Tareas ordenadas por prioridad.");
    }
    
    
    
}
