
package clases;

import java.util.LinkedList;
import java.util.List;

public class ListaDeTareas {
   
    private final List<Tarea> tareas;

    public ListaDeTareas() {
        this.tareas = new LinkedList<>();
    }

    
    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }


    public boolean eliminarTarea(String nombre) {
        return tareas.removeIf(t -> t.getNombre().equals(nombre));
    }

 
    public Tarea buscarTarea(String nombre) {
        return tareas.stream().filter(t -> t.getNombre().equals(nombre)).findFirst().orElse(null);
    }

   
    public String mostrarTareas() {
        StringBuilder sb = new StringBuilder();
        for (Tarea tarea : tareas) {
            sb.append(tarea.toString()).append("\n");
        }
        return sb.toString();
    }

   
    public void ordenarPorPrioridad() {
        tareas.sort((t1, t2) -> Integer.compare(t2.getPrioridad(), t1.getPrioridad()));
    }
}   
    
    
    

