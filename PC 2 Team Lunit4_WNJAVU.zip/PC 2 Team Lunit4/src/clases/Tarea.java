
package clases;

import java.time.LocalDate;

public class Tarea {
    private String nombre;
    private int prioridad;
    private String descripcion;
    private final LocalDate fechaCreacion;
    private String estado; 
    public Tarea(String nombre, int prioridad, String descripcion) {
        this.nombre = nombre;
        this.prioridad = prioridad;
        this.descripcion = descripcion;
        this.fechaCreacion = LocalDate.now();
        this.estado = "Pendiente"; // Estado inicial
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public String getEstado() {
        return estado;
    }

    public void cambiarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }

  
    @Override
    public String toString() {
        return "Tarea: " + nombre + ", Prioridad: " + prioridad + ", Estado: " + estado + 
               ", Fecha de creación: " + fechaCreacion + ", Descripción: " + descripcion;
    }
}  
    

